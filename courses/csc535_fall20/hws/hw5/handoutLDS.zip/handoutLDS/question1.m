clear variables;
close all;

seed = 0;
rng(seed);
figCount = 1;



%% 1b %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

numRuns = 3;
nParticles = 100;

plot_truth(states, data, figCount); figCount = figCount+1;
hold on;
[Xf, Pf] = kalman_smoother(model, data', x0, P0);
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
% run particle filter
for i=1:numRuns
    X_pf = particle_filter(nParticles, model, data', x0, P0);
    plot( 1:numel(data), X_pf(1,:), '.-c' );    
end

xlim([0, T+1]);
h=legend('True State', 'Measurement', 'Kalman Filter', 'Particle Filter', 'Location','northwest');

clear X_pf
%% 1c %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% TODO: Modify codes in 1b.


%% 1d %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
nParticles = 100;

% corrupt data
to_flip= rand(numel(data),1) < 0.1;
noisy_vals = 40*randn(numel(data),1);
noisy_data = (1-to_flip).*data + to_flip.*noisy_vals;

% run Kalman smoother
[Xf, Pf] = kalman_smoother(model, noisy_data', x0, P0);

% run particle filter for the noisy observation model
% Todo: modify your implementation of particle_filter.m to take into
% account the outlier noise model

% place your posterior-mean estimates in X_pf. The code below is just a
% place holder for your code
X_pf = zeros(numel(x0),numel(data));

% plot
plot_truth(states, noisy_data, figCount);figCount = figCount+1;
hold on;
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
plot( 1:T, X_pf(1,:), '.-c' );
hold off;
xlim([0, T+1]);
legend('True State', 'Measurement', 'Kalman Filter', 'Particle Filter','Location','northwest');

%% 1e %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TODO: Modify code in 1b/1c
