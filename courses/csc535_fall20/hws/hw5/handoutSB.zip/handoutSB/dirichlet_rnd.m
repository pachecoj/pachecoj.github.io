function ddraw = dirichlet_rnd(alpha, numsamps)
%dirichlet_rnd     Sample from Dirichlet distribution
%
%    ddraw = dirichlet_rnd(alpha, N)
%
%  Draws N independent samples from a Dirichlet distribution, where
%    alpha = K-dim. vector of Dirichlet parameters
%    ddraw = KxN matrix where each column is a sample

kdim = length(alpha);
a1 = zeros(kdim,numsamps);
for k = 1:kdim
    a1(k,:) = gamm_rnd(1,numsamps,alpha(k),1);
end
ddraw = a1./repmat(sum(a1,1),kdim,1);

