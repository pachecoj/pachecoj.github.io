% SAMPSON MONASTERY NETWORK
 
DESCRIPTION TAKEN FROM: http://vlado.fmf.uni-lj.si/pub/networks/data/ucinet/ucidata.htm#sampson

Sampson recorded the social interactions among a group of monks while resident as an experimenter on vision, and collected numerous sociometric rankings. This graph is a conglomeration of those sociometric rankings by Breiger et. al and describes in general the likability that one monk had for another.  During Sampson's stay, there was a political "crisis in the cloister", which resulted in the expulsion of four monks and the voluntary departure of several others. 

DATA: 
  graph         = NxN adjacency matrix of directed network of likability/praise relationships. 
  monk_names    = Nx1 cell array of monk names 
  monk_factions = Nx1 vector of faction labels. 1 = Young Turks (rebel group), 2 = Loyal Opposition (monks who followed tradition and remained loyal), 3 = Outcasts (Monks who were not accepted by either faction), 4 = Waverers (Monks who couldn't decide on a group).

REFERENCES: Breiger R., Boorman S. and Arabie P. (1975). An algorithm for clustering relational data with applications to social network analysis and comparison with multidimensional scaling.  Journal of Mathematical Psychology, 12, 328-383.
