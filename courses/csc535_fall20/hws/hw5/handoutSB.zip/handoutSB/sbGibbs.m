
function [z,pi,W,logProb,randI] = sbGibbs(adj,K,alpha,numIter,zTrue,zInit)
%sbGibbs    Gibbs sampler for stochastic block model
%
%INPUTS:
%   adj     -> NxN adjacency matrix for observed relation graph,
%              where negative entries indicate missing observations
%   K       -> number of communities
%   alpha   -> Dirichlet concentration parameter
%   numIter -> number of Gibbs sampling iterations
%   z       -> 1xN vector of initial community assignments
%OUTPUTS:
%   z       -> 1xN vector of final community assignments
%   pi      -> Kx1 vector of community membership probabilities
%   W       -> KxK matrix of community interaction probabilities

% static parameters
N = size(adj,1);

mask = ((ones(N) - eye(N)) > 0);
mask = mask .* (adj >= 0);

% default arguments
if nargin < 3
  alpha = 1.0;
end
if nargin < 4
  numIter = 1;
end
if nargin < 5
  zTrue = ones(1,N);
end
if nargin < 6
  z = multinomial_rnd(ones(K,1), N)';
else
  z = zInit;
end

% sampler state variables
pi = zeros(K,1);
W  = zeros(K,K);
logProb = zeros(numIter,1);
randI   = zeros(numIter,1);

fprintf(1,'SB Gibbs: ');
for tt = 1:numIter
  % TODO: sample mixture probabilities pi
  % pi = ?

  % TODO: sample community interaction parameters W
  for kk = 1:K
    for ll = 1:K
      %W(kk,ll) = ?
    end
  end

  % TODO: sample community assignments z in random order
  for ii = randperm(N)
    %z(ii) = ?
  end

  logProb(tt) = sbLogProb(adj, z, pi, W, alpha);
  [AR,RI] = valid_RandIndex(z,zTrue);
  randI(tt) = RI;
  if mod(tt, round(numIter/10))==0
    fprintf(1,'.');
  end
end
fprintf(1,'\n');

