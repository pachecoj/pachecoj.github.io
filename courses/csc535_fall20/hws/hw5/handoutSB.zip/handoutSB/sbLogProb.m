
function logProb = sbLogProb(adj, z, pi, W, alpha)
%sbLogProb    Joint log-probability for configuration of stochastic block model
%
%INPUTS:
%   adj     -> NxN adjacency matrix for observed relation graph
%   z       -> 1xN vector of community assignments
%   pi      -> Kx1 vector of community membership probabilities
%   W       -> KxK matrix of community interaction probabilities
%OUTPUTS:
%   logProb -> joint log-probability of all variables

% static parameters
N = size(adj,1);
K = length(pi);

mask = ((ones(N) - eye(N)) > 0);
mask = mask .* (adj >= 0);

% parameter probabilities
logProb = dirichlet_logprob(alpha*ones(K,1), pi);
for kk = 1:K
  for ll = 1:K
    logProb = logProb + dirichlet_logprob([1,1], [W(kk,ll),1-W(kk,ll)]);
  end
end

% community assignment probabilities
logPi = log(pi);
for ii = 1:N
  logProb = logProb + logPi(z(ii));
end

% observation likelihoods
logW  = log(W);
logMW = log(1-W);
for ii = 1:N
  for jj = find(mask(ii,:))
    src = z(ii);
    rcv = z(jj);
    logProb = logProb + adj(ii,jj)*logW(src,rcv) + (1-adj(ii,jj))*logMW(src,rcv);
  end
end

