function logProb = dirichlet_logprob(alpha, x)
%dirichlet_logprob     Log probability for Dirichlet distribution
%
%    logProb = dirichlet_logprob(alpha, x)
%
%  Returns log-probability of categorical distribution x under Dir(alpha)

logProb = gammaln(sum(alpha)) - sum(gammaln(alpha));
logProb = logProb + sum(log(x) .* (alpha-1));

