
function [labels,prob] = sbPredict(adj, mask, z, W)
%sbPredict    SB prediction of heldout test links
%
%INPUTS:
%   adj     -> NxN adjacency matrix for observed relation graph
%   mask    -> NxN matrix where negative values indicate test entries
%   z       -> 1xN vector of community assignments
%   W       -> KxK matrix of community interaction probabilities
%OUTPUTS:
%   labels  -> vector of true test labels
%   prob    -> vector of probabilities that labels equal one

% static parameters
N = size(adj,1);
K = size(W,1);

Ntest  = sum(sum(mask < 0));
labels = zeros(Ntest,1);
prob   = zeros(Ntest,1);
index  = 1;
for ii = 1:N
  for jj = 1:N
    if mask(ii,jj) < 0
      labels(index) = adj(ii,jj);
      
      %TODO: Compute probability that adj(ii,jj)=1
      %prob(index) = ?

      index = index + 1;
    end
  end
end

