
%
% Experiments with Toy Data: Question 2 
% UA CSC 535
%

% Set to run experiments for SB and/or MMSB models
runSB   = true;
runMMSB = true;
numTrial = 5;
numIter  = 1000;

% Generate toy dataset
N = 30;
K = 3;
zT = ones(1,N);
zT(11:20) = 2;
zT(21:30) = 3;
W = 0.1*ones(3) + (0.95-0.10)*eye(3);

adj = zeros(N);
for ii = 1:N
  for jj = 1:N
    if jj ~= ii
      edgePr = W(zT(ii),zT(jj));
      adj(ii,jj) = multinomial_rnd([1-edgePr, edgePr], 1);
      adj(ii,jj) = adj(ii,jj) - 1;
    end
  end
end

% Run block model Gibbs sampler, plot results
alphaSB = 1.0;
if runSB
  for qq = 1:numTrial
    [z,pi,W,logProb(:,qq),randI(:,qq)] = ...
      sbGibbs(adj, K, alphaSB, numIter, zT);
  end

  figure(1);
  plot(logProb);
  xlabel('Iteration'); ylabel('Log probability');

  figure(2);
  plot(randI);
  xlabel('Iteration'); ylabel('Rand index');
end

% Run MMSB Gibbs sampler, plot results
alphaMMSB = 0.1;
if runMMSB
  for qq = 1:numTrial
    [sM,rM,piM,WM,logProbM(:,qq),randIM(:,qq)] = ...
      mmsbGibbs(adj, K, alphaMMSB, numIter, zT, false);
    [sMB,rMB,piMB,WMB,logProbMB(:,qq),randIMB(:,qq)] = ...
      mmsbGibbs(adj, K, alphaMMSB, numIter, zT, true);
  end

  figure(3);
  plot(logProbM);
  xlabel('Iteration'); ylabel('Log probability');
  
  figure(4);
  plot(randIM);
  xlabel('Iteration'); ylabel('Rand index');
  
  figure(5);
  plot(logProbMB);
  xlabel('Iteration'); ylabel('Log probability');
  
  figure(6);
  plot(randIMB);
  xlabel('Iteration'); ylabel('Rand index');
end

return;


