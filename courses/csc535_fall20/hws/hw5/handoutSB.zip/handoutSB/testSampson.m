
%
% Experiments with Sampson Data: Question 2
% UA CSC 535
%

% Set to run experiments for SB and/or MMSB models
runSB   = true;
runMMSB = true;
numTrial = 5;
numIter  = 1000;

% Load Sampson dataset
load sampson_network;
K = 3;

% Run block model Gibbs sampler, plot results
alphaSB = 1.0;
if runSB
  for qq = 1:numTrial
    [z,pi,W,logProb(:,qq),randI(:,qq)] = ...
      sbGibbs(graph, K, alphaSB, numIter, monk_factions);
  end

  figure(1);
  plot(logProb);
  xlabel('Iteration'); ylabel('Log probability');
  
  figure(2);
  plot(randI);
  xlabel('Iteration'); ylabel('Rand index');
end
  
% Run MMSB Gibbs sampler, plot results
alphaMMSB = 0.1;
if runMMSB
  for qq = 1:numTrial
    [sM,rM,piM,WM,logProbM(:,qq),randIM(:,qq)] = ...
      mmsbGibbs(graph, K, alphaMMSB, numIter, monk_factions, false);
    [sMB,rMB,piMB,WMB,logProbMB(:,qq),randIMB(:,qq)] = ...
      mmsbGibbs(graph, K, alphaMMSB, numIter, monk_factions, true);
  end

  % Below we create several relevant plots.  To answer all questions, 
  % you will also need to examine some of the estimated model parameters.
  
  figure(3);
  plot(logProbM);
  xlabel('Iteration'); ylabel('Log probability');
  
  figure(4);
  plot(randIM);
  xlabel('Iteration'); ylabel('Rand index');
  
  figure(5);
  plot(logProbMB);
  xlabel('Iteration'); ylabel('Log probability');
  
  figure(6);
  plot(randIMB);
  xlabel('Iteration'); ylabel('Rand index');
end

return;
print -f1 -depsc2 sampProb
print -f2 -depsc2 sampRand
print -f3 -depsc2 sampProbM
print -f4 -depsc2 sampRandM
print -f5 -depsc2 sampProbMB
print -f6 -depsc2 sampRandMB

print -f3 -depsc2 sampProbMsmall
print -f4 -depsc2 sampRandMsmall
print -f5 -depsc2 sampProbMBsmall
print -f6 -depsc2 sampRandMBsmall

