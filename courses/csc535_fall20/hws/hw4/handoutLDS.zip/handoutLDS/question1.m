clear variables;
close all;

seed = 0;
rng(seed);
figCount = 1;

%% 1b %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

load('track','states','data','model','x0','P0');
% Model is a data structure that contains fields: A,Q,R,C, which correspond
% to the parameters defined in Question 1 of the handout.
T = numel(data);

[Xf, Pf] = kalman_smoother(model, data', x0, P0);
close all;
plot_truth(states,data,figCount); figCount=figCount+1;
hold on;
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
hold off;
xlim([0, T+1]);
legend('True State', 'Measurement', 'Kalman Filter', 'Location','northwest');

clear Xf Pf
%% 1c %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% set initial conditions
% Todo: MODIFY 'P0_1d' and 'x0_1d' to the corresponding 1-d initial conditions
P0_1d = P0;
x0_1d = x0;    

model_1d = model;
% Todo: MODIFY 'model_1d' data structure to use the 1d case here


[Xf, Pf] = kalman_smoother(model_1d, data', x0_1d, P0_1d);
plot_truth(states, data, figCount); figCount=figCount+1;
hold on;
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
hold off;
xlim([0, T+1]);
legend('True State', 'Measurement', 'Kalman Filter', 'Location','northwest');

model_1d = model;
% Todo: MODIFY 'model_1d' data structure to use the 1d case here


[Xf, Pf] = kalman_smoother(model_1d, data', x0_1d, P0_1d);
plot_truth(states, data, figCount); figCount=figCount+1;
hold on;
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
hold off;
xlim([0, T+1]);
legend('True State', 'Measurement', 'Kalman Filter', 'Location','northwest');

clear x0_1d P0_1d model_1d

%% 1d %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% corrupt data
to_flip= rand(numel(data),1) < 0.1;
noisy_vals = 40*randn(numel(data),1);
noisy_data = (1-to_flip).*data + to_flip.*noisy_vals;

% run Kalman smoother
[Xf, Pf] = kalman_smoother(model, noisy_data', x0, P0);

% plot
plot_truth(states, noisy_data, figCount);figCount = figCount+1;
hold on;
E = shiftdim(2*sqrt( Pf(1,1,:) ), 1);
errorbar( 1:T, Xf(1,:), E, '.k' );
hold off;
xlim([0, T+1]);
legend('True State', 'Measurement', 'Kalman Filter', 'Location','northwest');
