function [ model, ll_iter ] = em_slds(...
  model_init, x0_init, P0_init, data, max_iters, conv_tol)
% EM_SLDS - EM for learning the Switching LDS.  This is a heuristic
%   approximation to the optimal approach.
%
% Inputs:
%  model_init: A cell structure storing the initial data model structure.
%              Each cell contains the fields A_k,C_k,Q_k,R_k as defined 
%              in the handout. If the input is a non-switching state
%              model, the function will convert the model structure to
%              a one dimensional cell structure, and also convert the
%              data structure for variable "data", as defined below.
%          x0: guess for the initial state
%          P0: covariance matrix on the initial state
%        data: Training data for each state. Each cell contain multiple 
%              sequences of D x T vector of time-series data. For
%              non-switching state inputs with single training instance, 
%              the function will convert it into a one dimensional cell.
%   max_iters: Maximum #iterations.
%    conv_tol: Tolearnce for convergence.
%
% Outputs:
%    model: The same data structure as "model_init", storing the learned
%           A_k, C_k, Q_k, R_k
%  ll_iter: A vector storing the log-likelihood bound for each iteration.
%
%
% University of Arizona CSC535

  num_states = numel(model_init);
  if num_states==1 && ~ischar(model_init)
      model_init = {model_init};
      data = {{data'}};
  end
  
  % init stuff  
  done = false;  
  iters = 0;
  ll_old = -Inf;
  ll_iter = [];
  model = model_init;
  x0 = x0_init;
  P0 = P0_init;
  
  D = numel(x0);
  
  % Main Loop
  while ~done
    iters = iters+1;
    fprintf('\nIter #%d: ', iters);
    
    %% E-step %%%%%%%%%%%%%
    
    % init stuff
    Eedge = cell([num_states,1]);
    Exx = cell([num_states,1]);    
    Xs = cell([num_states,1]);    
    Ps = cell([num_states,1]); 
    Xf = cell([num_states,1]);
    Pf = cell([num_states,1]);
    Nscans = cell([num_states, 1]);
    
    % compute statistics
    for k=1:num_states
      num_seq = numel( data{k} );
      Eedge{k} = cell([num_seq, 1]);
      Exx{k} = cell([num_seq, 1]);
      Xf{k} = cell([num_seq,1]);
      Xs{k} = cell([num_seq,1]);
      Xs{k} = cell([num_seq,1]);    
      Ps{k} = cell([num_seq,1]);    
      Nscans{k} = cell([num_seq,1]);
      
      % iterate over sequences
      for i_seq = 1:num_seq
        Nscans{k}{i_seq} = size(data{k}{i_seq},2);
        
        % run Kalman smoother
        [ Xf{k}{i_seq}, Pf{k}{i_seq}, Xs{k}{i_seq}, Ps{k}{i_seq} ] = ...
          kalman_smoother(model{k}, data{k}{i_seq}, x0, P0 );
        
        P = zeros( D, D, Nscans{k}{i_seq} );
        P_pred = zeros( D, D, Nscans{k}{i_seq} );
        for t=1:Nscans{k}{i_seq}

          % Prediction Step
          if t>1
              P_pred(:,:,t) = model{k}.A*P(:,:,t-1)*model{k}.A' + model{k}.Q;
          else
              P_pred(:,:,t) = P0;
          end

          K = P_pred(:,:,t) * model{k}.C' / (model{k}.C*P_pred(:,:,t)*model{k}.C' + model{k}.R);
          P(:,:,t) = (eye(D) - K*model{k}.C)*P_pred(:,:,t);
        end
      
      
        for t=1:Nscans{k}{i_seq}     

          % E[x_t x_t']
          Exx{k}{i_seq}(:,:,t) = Ps{k}{i_seq}(:,:,t) + Xs{k}{i_seq}(:,t) * Xs{k}{i_seq}(:,t)';

          % E[x_t x_{t-1}']
          if t>=2
            C = Pf{k}{i_seq}(:,:,t-1) * model{k}.A' / P_pred(:,:,t);
            Eedge{k}{i_seq}(:,:,t) = ...
              Ps{k}{i_seq}(:,:,t) * C' + Xs{k}{i_seq}(:,t) * Xs{k}{i_seq}(:,t-1)';      
          end
          
          % check conditions
          if rcond(Exx{k}{i_seq}(:,:,t)) <= 1e-9
            fprintf('\nWARNING Matrix Exx{%d}{%d} ill-conditioned at time %d.', k, i_seq, t);
          end
          if rcond(Eedge{k}{i_seq}(:,:,t)) <= 1e-9
            fprintf('\nWARNING Matrix Eedge{%d}{%d} ill-conditioned at time %d.', k, i_seq, t);
          end
        end
      end
    end
    
    % compute free energy
    ll = 0;
    for k = 1:num_states
        for i_seq = 1:length(Nscans{k})
            % TODO: implement compute_lds_bound()
            ll = ll + compute_lds_bound(model{k}, data{k}{i_seq}, ...
                                        x0, P0, Xf{k}{i_seq}, Pf{k}{i_seq});
        end
    end    


    ll_iter = [ ll_iter; ll ];
    if iters>1
      if ll < ll_old
          error('LL dropped, something is wrong');
      end
      diff = (ll - ll_old)/abs(ll);
      fprintf('LL: %0.3f, D: %0.4f', ll, diff);
      if ( ( diff < conv_tol ) || (iters >= max_iters) )
        break;
      end
    end
    ll_old = ll;
    
    
    %% M-step %%%%%%%%%%%%    
    for k=1:num_states
      A_new = 0; Q_new = 0; Q_new_T = 0; C_new = 0; R_new = 0; R_new_T = 0; 
      
      % compute stats
      Eedge_sum = 0; Exx_sum = 0; Exx_head_sum = 0;
      for i_seq = 1:numel(data{k})
        Eedge_sum = Eedge_sum + sum( Eedge{k}{i_seq}, 3);
        Exx_sum = Exx_sum + sum( Exx{k}{i_seq}, 3 );
        Exx_head_sum = Exx_head_sum + sum( Exx{k}{i_seq}(:,:,1:(end-1)), 3);
      end

      % dynamics
      A_new = A_new + Eedge_sum / Exx_head_sum;
      for i_seq = 1:numel(data{k})
        for t=2:Nscans{k}{i_seq}
          Q_new = Q_new + Exx{k}{i_seq}(:,:,t) - A_new * Eedge{k}{i_seq}(:,:,t)' ...
            - Eedge{k}{i_seq}(:,:,t) * A_new' + A_new * Exx{k}{i_seq}(:,:,t-1) * A_new';
        end        
      end
      Q_new = 1/(sum(cell2mat(Nscans{k}))-1) * Q_new;
      for i_seq = 1:numel(data{k})
        for t=2:Nscans{k}{i_seq}
          Q_new_T = Q_new_T + Exx{k}{i_seq}(:,:,t)' - Eedge{k}{i_seq}(:,:,t) * A_new'...
            - A_new*Eedge{k}{i_seq}(:,:,t)' + A_new * Exx{k}{i_seq}(:,:,t-1)' * A_new';
        end        
      end
      Q_new_T = 1/(sum(cell2mat(Nscans{k}))-1) * Q_new_T;
      Q_new = 0.5 * ( Q_new + Q_new_T );

      % observation
      C_new = model{k}.C;
      for i_seq = 1:numel(data{k})
        for t=1:Nscans{k}{i_seq}
          R_new = R_new + data{k}{i_seq}(:,t) * data{k}{i_seq}(:,t)' ...
            - C_new * Xs{k}{i_seq}(:,t) * data{k}{i_seq}(:,t)' ...
            - data{k}{i_seq}(:,t) * Xs{k}{i_seq}(:,t)' * C_new' ...
            + C_new * Exx{k}{i_seq}(:,:,t) * C_new';
        end
      end
      R_new = 1/sum(cell2mat(Nscans{k})) * R_new;
      for i_seq = 1:numel(data{k})
        for t=1:Nscans{k}{i_seq}
          R_new_T = R_new_T + data{k}{i_seq}(:,t) * data{k}{i_seq}(:,t)' ...
            - C_new * Xs{k}{i_seq}(:,t) * data{k}{i_seq}(:,t)' ...
            - data{k}{i_seq}(:,t) * Xs{k}{i_seq}(:,t)' * C_new' ...
            + C_new * Exx{k}{i_seq}(:,:,t)' * C_new';
        end
      end
      R_new_T = 1/sum(cell2mat(Nscans{k})) * R_new_T;      
      R_new = 0.5 * ( R_new + R_new_T );
      
      % update model
      model{k}.A = A_new;
      model{k}.Q = Q_new;
      model{k}.C = C_new;
      model{k}.R = R_new;
    
    end
    
  end
  
  for(k=1:numel(model))
     model{k}.Q = (model{k}.Q + model{k}.Q')/2;
  end
  
end
