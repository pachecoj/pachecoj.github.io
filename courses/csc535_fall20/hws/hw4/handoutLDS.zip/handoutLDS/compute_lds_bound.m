function ll = compute_lds_bound(model, data, x0, P0, Xf, Pf)
% COMPUTE_LDS_BOUND - Computes the EM lower bound ("auxilliary function")
%   for the linear dynamical system with model parameters 'model'.
%
% University of Arizona CSC535

  T = size(data,2);
  D = numel(Xf(:,1));

  % unpack alphabet
  [ A, C, Q, R ] = deal( model.A, model.C, model.Q, model.R );
  
  % TODO: compute bound
  ll = 0;
  
end
