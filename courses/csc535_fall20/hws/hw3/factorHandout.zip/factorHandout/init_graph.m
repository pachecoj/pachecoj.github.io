function G = init_graph()
% INIT_GRAPH - Initialize factor graph data structure.
%
% University of Arizona CSC535

  G.var = []; % Variable nodes
  G.fac = []; % Factor nodes  
end
